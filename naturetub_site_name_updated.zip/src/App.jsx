import React, { useState, useEffect } from "react";


// --- UPI & WhatsApp helpers ---
function openUPI(vpa, name, amount) {
  const am = Math.round(Number(amount) * 100); // paise
  const upiUrl = `upi://pay?pa=${encodeURIComponent(vpa)}&pn=${encodeURIComponent(name)}&am=${(am/100).toFixed(2)}&cu=INR`;
  window.location.href = upiUrl;
}

function getUPIQRCodeURL(vpa, name, amount) {
  const upiLink = `upi://pay?pa=${encodeURIComponent(vpa)}&pn=${encodeURIComponent(name)}&am=${encodeURIComponent(amount)}&cu=INR`;
  const qr = `https://chart.googleapis.com/chart?chs=300x300&cht=qr&chl=${encodeURIComponent(upiLink)}`;
  return qr;
}

function whatsappOrderLink(cart) {
  const phone = '919317948152'; // replace with your WhatsApp number (country code, no +)
  const items = cart.map(i => `${i.title_en} x${i.qty}`).join('\n');
  const total = cart.reduce((s,i)=>s + i.salePrice * i.qty,0);
  const msg = `Hello, I would like to place an order:%0A${encodeURIComponent(items)}%0A%0ATotal: ₹${total}%0A%0AName:%20%0AAddress:%20%0APincode:%20%0APlease confirm availability and payment instructions.`;
  return `https://wa.me/${phone}?text=${msg}`;
}
const productsData = [
  { id: 1, category: "Gud & Jaggery", slug: "gud-jaggery", title_en: "Gud (Whole Jaggery)", title_hi: "गुड़ (गोल गुड़)", price: 250, salePrice: 220, badge: "Save ₹30", short: "Traditional solid jaggery blocks — rich flavor.", desc_hi: "पारंपरिक तरीके से बने गुड़ के गोले — शुद्धता और प्राकृतिक स्वाद के साथ।", images: ["/uploads/1.png","/uploads/2.webp","/uploads/3.jpg"] },
  { id: 2, category: "Gud & Jaggery", slug: "jaggery-powder", title_en: "Jaggery Powder", title_hi: "गुड़ पाउडर", price: 180, salePrice: 160, badge: "Save ₹20", short: "Fine jaggery powder — natural sweetener.", desc_hi: "शुद्ध गुड़ पाउडर...", images: ["/uploads/4.jpg","/uploads/5.jpg"] },
  { id: 3, category: "Makhana", slug: "makhana-plain", title_en: "Makhana (Plain)", title_hi: "मखाना", price: 320, salePrice: 280, badge: "Save ₹40", short: "Crisp lotus seeds — perfect snack and healthy ingredient.", desc_hi: "हल्का, कुरकुरा...", images: ["/uploads/6.jpg","/uploads/7.jpeg"] },
  { id: 4, category: "Dryfruits", slug: "dryfruits-mix", title_en: "Premium Dry Fruits Mix", title_hi: "ड्राय फ्रूट्स", price: 699, salePrice: 649, badge: "Save ₹50", short: "Almonds, cashews, raisins & more.", desc_hi: "उच्च गुणवत्ता वाले...", images: ["/uploads/8.jpeg","/uploads/9.jpeg"] },
  { id: 5, category: "Spices", slug: "spice-collection", title_en: "Whole & Ground Spices", title_hi: "मसाले", price: 199, salePrice: 169, badge: "Save ₹30", short: "Aromatic spices sourced & packed hygienically.", desc_hi: "खुशबूदार और शुद्ध मसाले...", images: ["/uploads/10.jpeg","/uploads/11.jpeg"] },
  { id: 6, category: "Ghee", slug: "desi-ghee", title_en: "Pure Desi Ghee", title_hi: "देशी घी", price: 599, salePrice: 549, badge: "Save ₹50", short: "Golden, aromatic desi ghee.", desc_hi: "हमारा देसी घी शुद्ध...", images: ["/uploads/12.jpeg","/uploads/13.jpeg"] },
  { id: 7, category: "Pulses", slug: "mixed-pulses-1kg", title_en: "Mixed Pulses Pack (1kg)", title_hi: "मिक्स दालें (1kg)", price: 149, salePrice: 129, badge: "Save ₹20", short: "High-quality pulses mix.", desc_hi: "ताज़ी और उच्च गुणवत्ता वाली दालें...", images: ["/uploads/14.jpeg"] },
  { id: 8, category: "Dehydrated Fruits", slug: "dehydrated-mango-250g", title_en: "Dehydrated Mango (250g)", title_hi: "डिहाइड्रेटेड आम (250g)", price: 249, salePrice: 219, badge: "Save ₹30", short: "Naturally dried mango slices.", desc_hi: "प्राकृतिक तरीके से सुखाये गए आम...", images: ["/uploads/15.jpeg"] }
];

export default function App(){
  const [products,setProducts] = useState(productsData);
  const [query,setQuery] = useState("");
  const [cat,setCat] = useState('All');
  const [cart,setCart] = useState([]);
  const [quick, setQuick] = useState(null);

  useEffect(()=>{
    let filtered = productsData.filter(p => (p.title_en + p.title_hi + p.short).toLowerCase().includes(query.toLowerCase()));
    if(cat !== 'All') filtered = filtered.filter(p => p.category === cat);
    setProducts(filtered);
  },[query,cat]);

  function addToCart(p){
    setCart(c=>{
      const found = c.find(i=>i.id===p.id);
      if(found) return c.map(i=> i.id===p.id ? {...i, qty: i.qty+1} : i);
      return [...c, {...p, qty:1}];
    });
  }

  return (<div>
    <header className="shadow" style={{padding:'12px 0',background:'#fff'}}>
      <div className="container" style={{display:'flex',alignItems:'center',gap:16}}>
        <div style={{display:'flex',gap:12,alignItems:'center'}}>
          <div style={{width:44,height:44,background:'#bbf7d0',borderRadius:8,display:'flex',alignItems:'center',justifyContent:'center',fontWeight:700}}>NT</div>
          <div><div style={{fontWeight:700}}>Nature Tub</div><div style={{fontSize:12,color:'#6b7280'}}>Natural • Hygienic • Repacked</div></div>
        </div>
        <input value={query} onChange={e=>setQuery(e.target.value)} placeholder="Search products..." style={{flex:1,padding:8,borderRadius:8,border:'1px solid #e5e7eb'}}/>
        <div style={{display:'flex',gap:12,alignItems:'center'}}><div>Cart: {cart.reduce((s,i)=>s+i.qty,0)}</div></div>
      </div>
    </header>

    <main className="container" style={{padding:'24px 0'}}>
      <div style={{display:'flex',gap:16}}>
        <aside style={{width:220}}>
          <div className="shadow rounded" style={{padding:12,background:'#fff'}}>
            <div style={{fontWeight:600,marginBottom:8}}>Categories</div>
            <div style={{display:'flex',flexDirection:'column',gap:6}}>
              {['All',...new Set(productsData.map(p=>p.category))].map(c=> <button key={c} onClick={()=>setCat(c)} style={{textAlign:'left',padding:8,background:c===cat?'#ecfccb':'transparent',borderRadius:6}}>{c}</button>)}
            </div>
          </div>
        </aside>

        <section style={{flex:1}}>
          <div style={{display:'flex',justifyContent:'space-between',alignItems:'center',marginBottom:12}}>
            <h2 style={{margin:0}}>Products</h2>
            <div style={{color:'#6b7280'}}>Showing {products.length}</div>
          </div>

          <div className="grid grid-cols-4">
            {products.map(p=> <article key={p.id} className="shadow rounded" style={{padding:12,background:'#fff',display:'flex',flexDirection:'column'}}>
              <img className="img-cover" src={p.images[0]} alt={p.title_en}/>
              <div style={{marginTop:8,fontWeight:600}}>{p.title_en} — {p.title_hi}</div>
              <div style={{color:'#6b7280',fontSize:13,marginTop:6}}>{p.short}</div>
              <div style={{marginTop:'auto',display:'flex',justifyContent:'space-between',alignItems:'center',marginTop:12}}>
                <div><span style={{color:'#059669',fontWeight:700}}>₹{p.salePrice}</span> <span style={{textDecoration:'line-through',color:'#9ca3af',marginLeft:6}}>₹{p.price}</span></div>
                <div style={{display:'flex',gap:8}}>
                  <button onClick={()=>setQuick(p)} className="btn">Quick View</button>
                  <button onClick={()=>addToCart(p)} className="btn">Add</button>
                </div>
              </div>
            </article>)}
          </div>
        </section>
      </div>
    </main>

    {quick && <div style={{position:'fixed',inset:0,background:'rgba(0,0,0,0.5)',display:'flex',alignItems:'center',justifyContent:'center'}}>
      <div style={{width:'90%',maxWidth:900,background:'#fff',padding:16,borderRadius:8}}>
        <div style={{display:'flex',gap:12}}>
          <img src={quick.images[0]} alt="" style={{width:320,height:320,objectFit:'cover',borderRadius:8}}/>
          <div style={{flex:1}}>
            <h3>{quick.title_en} — {quick.title_hi}</h3>
            <p style={{color:'#6b7280'}}>{quick.desc_hi}</p>
            <div style={{marginTop:12,fontWeight:700}}>₹{quick.salePrice} <span style={{textDecoration:'line-through',color:'#9ca3af',marginLeft:6}}>₹{quick.price}</span></div>
            <div style={{marginTop:12,display:'flex',gap:8}}>
              <button onClick={()=>{ setQuick(null); }} className="btn">Close</button>
              <button onClick={()=>{ addToCart(quick); setQuick(null); }} className="btn">Add to cart</button>
            </div>
          </div>
        </div>
      </div>
    </div>}

  </div>)
}
