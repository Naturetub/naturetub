# Nature Tub — React Demo Site

This repository is a ready-to-deploy React front-end prototype and a Node/Express example server for Razorpay integration.

## What's included
- `src/` — React app (Vite) with product grid, quick view, cart (local), and checkout mock.
- `public/uploads/` — product images (copied from your uploaded images).
- `server/` — Node/Express example that demonstrates how to create Razorpay orders (you must provide API keys).

## Quick local setup (front-end)
1. Install Node (18+ recommended).
2. In project root:
   ```
   npm install
   npm run dev
   ```
   Open `http://localhost:5173`.

## Server (Razorpay order creation) — optional (for live payments)
1. Go to `server/` folder and run:
   ```
   cd server
   npm install
   RP_KEY_ID=your_key_id RP_KEY_SECRET=your_key_secret node server.js
   ```
2. The server will run on port 3000 by default and exposes `/create-order` to create orders.
3. On the client, call your server `/create-order` with a JSON body like:
   ```
   { "amount": 10000 }
   ```
   (Amount is in paise — 10000 = ₹100.00). Use returned `order.id` in Razorpay checkout.

## Deployment
- Front-end: Deploy to Vercel / Netlify by connecting this repo or uploading the folder. Vite builds a static bundle.
- Server: Deploy on Render / Railway / Heroku and set env vars for `RP_KEY_ID` and `RP_KEY_SECRET`.

## Next steps I can do for you
1. Integrate Razorpay checkout on the front-end and show a demo using the above server.
2. Optimize all images for web (thumbnails + large).
3. Make a pixel-perfect Farmley-style theme (fonts, spacing) and mobile mockups.

## UPI & WhatsApp order options (added)
- Front-end has buttons to open UPI intent (deep link) with a merchant VPA (you must replace the VPA when prompted or set it in code).
- Users can open a UPI QR (Google Chart API) or send the order via WhatsApp using a prefilled message.

To enable live UPI payments via Razorpay, follow the README section 'Server (Razorpay order creation)'.



## Configured Merchant Info
- Default UPI VPA set to: `9317948152m@pnb` (Nature Tub, PNB)
- WhatsApp order button sends to: +91 9317948152

## Merchant UPI & WhatsApp prefilled
- Merchant UPI VPA prefilled: 9317948152m@pnb
- WhatsApp number set for orders: +919317948152

Customers clicking 'Pay via UPI' will open their UPI app with the merchant VPA prefilled. 'Open UPI QR' will open a QR for the same VPA. 'Send order via WhatsApp' opens chat with the prefilled message to the merchant number.
