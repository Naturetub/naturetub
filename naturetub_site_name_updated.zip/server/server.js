const express = require('express');
const Razorpay = require('razorpay');
const cors = require('cors');

const app = express();
app.use(express.json());
app.use(cors());

const RAZORPAY_KEY_ID = process.env.RP_KEY_ID || 'YOUR_KEY_ID';
const RAZORPAY_KEY_SECRET = process.env.RP_KEY_SECRET || 'YOUR_KEY_SECRET';

const razorpay = new Razorpay({
  key_id: RAZORPAY_KEY_ID,
  key_secret: RAZORPAY_KEY_SECRET
});

app.post('/create-order', async (req, res) => {
  try {
    const { amount, currency, receipt } = req.body;
    const options = { amount: amount, currency: currency || 'INR', receipt: receipt || 'receipt#1' };
    const order = await razorpay.orders.create(options);
    res.json(order);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Unable to create order' });
  }
});

app.get('/', (req,res)=> res.send('Razorpay server example. Set RP_KEY_ID & RP_KEY_SECRET env vars.') );

const PORT = process.env.PORT || 3000;
app.listen(PORT, ()=> console.log('Server listening on', PORT));


// Razorpay webhook endpoint example:
// Set environment variable RAZORPAY_WEBHOOK_SECRET with your webhook secret from Razorpay dashboard
app.post('/razorpay-webhook', express.raw({type: 'application/json'}), (req, res) => {
  const crypto = require('crypto');
  const secret = process.env.RAZORPAY_WEBHOOK_SECRET || 'YOUR_WEBHOOK_SECRET';
  const shasum = crypto.createHmac('sha256', secret);
  shasum.update(req.body);
  const digest = shasum.digest('hex');

  const receivedSignature = req.headers['x-razorpay-signature'];
  if (digest === receivedSignature) {
    console.log('Valid webhook received:', req.body);
    // handle event
    res.json({status: 'ok'});
  } else {
    console.log('Invalid webhook signature');
    res.status(400).json({error: 'invalid signature'});
  }
});
